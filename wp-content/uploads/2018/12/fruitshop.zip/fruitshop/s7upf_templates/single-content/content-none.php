<div class="text-center">
<?php esc_html_e('No post to display. Please create post !','fruitshop');?>
</div>